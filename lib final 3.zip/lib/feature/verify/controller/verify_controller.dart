import 'package:get/get.dart';

class VerifyController extends GetxController{




}