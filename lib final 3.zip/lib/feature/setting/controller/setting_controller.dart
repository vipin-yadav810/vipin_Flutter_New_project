import 'package:get/get.dart';

class SettingController extends GetxController{






}