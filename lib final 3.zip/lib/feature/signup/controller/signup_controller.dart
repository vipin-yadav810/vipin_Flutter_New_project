
import 'package:get/get.dart';

class SignupController extends GetxController {


}

