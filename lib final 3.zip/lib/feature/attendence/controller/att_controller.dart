import 'package:get/get.dart';

class AttController extends GetxController{





}