class Onboardingpages {
  final imageAsset;
  final title;
  final description;

  Onboardingpages(this.imageAsset, this.title, this.description);
}