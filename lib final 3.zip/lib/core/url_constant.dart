class URLConstant{
  static const String baseUrl ='https://ubiattendance.ubiattendance.xyz/newpanel/index.php/Att_services_getx_xyz_regendra/';
  static const String signup = 'insertDataTest?';






}