class RouteConstant{
  static const String splash = '/splash_view.dart';
  static const String home = '/home_view.dart';
  static const String login = '/login_view.dart';
  static const String onboarding = '/onboarding_view.dart';
  static const String signup ='/signup_view.dart';
  static const String verify ='/verify_view.dart';
  static const String detail ='/detail_view.dart';
  static const String home2 ='/home2_page.dart';
  static const String profile ='/profile_page.dart';
  static const String nav ='/fetchup_page.dart';
  static const String att ='/att_view.dart';
  static const String setting ='/setting_view.dart';


}